// RENDERER: draws the animation. This replaces the Flash movie (kona_dancer_main.swf).
const FPS = 15;                                   // from the SWF header
const SHADOW_COLORS = ['#0000FF', '#0000CC', '#000099'];   // setRGB colours in the original script
const canvas = document.getElementById('c'), ctx = canvas.getContext('2d');
const tint = document.createElement('canvas'); tint.width = 500; tint.height = 300;
const tctx = tint.getContext('2d');

const frames = Array.from({ length: 160 }, (_, i) => {
  const img = new Image(); img.src = `../assets/frames/f${String(i).padStart(3, '0')}.png`; return img;
});

let settings = { transparent: false, shadow: false };
let t = 0;                                         // current position on the timeline

function frameAt(n) { return frames[TIMELINE[((n % TIMELINE.length) + TIMELINE.length) % TIMELINE.length]]; }

function draw() {
  ctx.clearRect(0, 0, 500, 300);
  // Dancer: 100% opaque, or 65% when "Transparent" is on (original: dancer_mc._alpha = 65)
  ctx.globalAlpha = settings.transparent ? 0.65 : 1;
  ctx.drawImage(frameAt(t), 0, 0);
  if (settings.shadow) {
    // 3 echo copies, each lagging i frames behind, tinted blue, faded.
    // Original alpha: 55-10*i (or 35-10*i when transparent). Drawn i=3,2,1 so i=1 ends up on top.
    for (let i = 3; i >= 1; i--) {
      tctx.globalCompositeOperation = 'source-over'; tctx.clearRect(0, 0, 500, 300);
      tctx.drawImage(frameAt(t - i), 0, 0);
      tctx.globalCompositeOperation = 'source-in';  // keep the silhouette, replace the colour
      tctx.fillStyle = SHADOW_COLORS[i - 1]; tctx.fillRect(0, 0, 500, 300);
      ctx.globalAlpha = (settings.transparent ? 35 - 10 * i : 55 - 10 * i) / 100;
      ctx.drawImage(tint, 0, 0);
    }
  }
  ctx.globalAlpha = 1;
}

setInterval(() => { t = (t + 1) % TIMELINE.length; draw(); }, 1000 / FPS);

// ---- mouse: drag to move, right-click for the menu ----
canvas.addEventListener('mousedown', (e) => { if (e.button === 0 && window.api) window.api.dragStart(); });
window.addEventListener('mouseup',   () => window.api && window.api.dragEnd());
canvas.addEventListener('contextmenu', (e) => { e.preventDefault(); window.api && window.api.showMenu(); });

if (window.api) {
  window.api.onState((s) => { settings = s; });
} else {                                           // browser preview mode (no Electron)
  document.body.classList.add('preview'); document.getElementById('bar').hidden = false;
  document.getElementById('tr').onchange = (e) => settings.transparent = e.target.checked;
  document.getElementById('sh').onchange = (e) => settings.shadow = e.target.checked;
}
