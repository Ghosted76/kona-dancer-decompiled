// PRELOAD: a tiny, safe bridge. The web page can ONLY call these 4 things - nothing else on your PC.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  showMenu:  () => ipcRenderer.send('show-menu'),
  dragStart: () => ipcRenderer.send('drag-start'),
  dragEnd:   () => ipcRenderer.send('drag-end'),
  onState:   (cb) => ipcRenderer.on('state', (_e, s) => cb(s))
});
