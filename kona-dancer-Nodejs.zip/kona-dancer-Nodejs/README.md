To run:
1. install Node.js (https://nodejs.org, the LTS version.)
2. in folder open a terminal (Be sure to use command prompt)
3. in folder run "npm install" (if problems with version run "electron@33.4.11 (postinstall: node install.js)")
4. in folder run "npm start"

and you're done.

if you'd like to test run it via HTML go to"kona-dancer -> renderer -> index.html" and double click that.
