// MAIN PROCESS: the "operating system" side. It owns the window, tray icon and menu.
const { app, BrowserWindow, Tray, Menu, ipcMain, screen, dialog, nativeImage } = require('electron');
const path = require('path');

// Remembered settings (the original kept these in Flash variables: tCheck, sCheck, atName...)
const state = { transparent: false, shadow: false, zorder: 'top' };
let win, tray, dragTimer = null;

if (!app.requestSingleInstanceLock()) app.quit();   // only one dancer at a time

function createWindow() {
  win = new BrowserWindow({
    width: 500, height: 300,          // same size as the original SWF stage
    transparent: true,                // per-pixel transparency (the PNG alpha channel)
    frame: false,                     // no title bar / border
    hasShadow: false,
    resizable: false,
    alwaysOnTop: true,                // original called mWindow.setZOrder(TOP)
    title: 'Kona_Dancer',             // original called mWindow.setTitle('Kona_Dancer')
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
  });
  win.loadFile('renderer/index.html');
  win.webContents.on('did-finish-load', pushState);
}

function pushState() { win.webContents.send('state', state); }

function setZOrder(mode) {
  state.zorder = mode;
  win.setAlwaysOnTop(mode === 'top', 'floating');
}

// Same menu as the original mMenu: Minimize, Transparent, Show shadow | Always on top, Standard | About, Exit
function buildMenu() {
  return Menu.buildFromTemplate([
    { label: 'Minimize', click: () => win.minimize() },
    { label: 'Transparent', type: 'checkbox', checked: state.transparent,
      click: (i) => { state.transparent = i.checked; pushState(); } },
    { label: 'Show shadow', type: 'checkbox', checked: state.shadow,
      click: (i) => { state.shadow = i.checked; pushState(); } },
    { type: 'separator' },
    { label: 'Always on top', type: 'radio', checked: state.zorder === 'top', click: () => setZOrder('top') },
    { label: 'Standard', type: 'radio', checked: state.zorder === 'standard', click: () => setZOrder('standard') },
    { type: 'separator' },
    { label: 'About', click: () => dialog.showMessageBox(win, {
        title: 'About', message: 'Kona Dancer (remake)',
        detail: 'Rebuilt from the original SWF animation.\nFan project - Konata (Lucky Star) (c) Kagami Yoshimizu.' }) },
    { label: 'Exit', click: () => app.quit() }
  ]);
}

ipcMain.on('show-menu', () => buildMenu().popup({ window: win }));

// Dragging: the renderer says "mouse down" / "mouse up"; we follow the cursor in between.
ipcMain.on('drag-start', () => {
  const c = screen.getCursorScreenPoint(), [wx, wy] = win.getPosition();
  const dx = c.x - wx, dy = c.y - wy;
  clearInterval(dragTimer);
  dragTimer = setInterval(() => {
    const n = screen.getCursorScreenPoint();
    win.setPosition(n.x - dx, n.y - dy);
  }, 8);
});
ipcMain.on('drag-end', () => clearInterval(dragTimer));

app.whenReady().then(() => {
  createWindow();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray.png')).resize({ width: 16, height: 16 }));
  tray.setToolTip('Kona Dancer');
  tray.setContextMenu(buildMenu());
  tray.on('click', () => (win.isMinimized() || !win.isVisible()) ? (win.restore(), win.show()) : win.minimize());
});
app.on('window-all-closed', () => app.quit());
